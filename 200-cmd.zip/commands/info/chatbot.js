const msg = require("discord.js");
module.exports = {
  name: "chatbot",
  category: "info",
  description: "Returns latency and API ping",
  run: async (client, message, args) => {
    
  }
  }
